rater = """
<style>
body {
    font-family: Arial, sans-serif;
    padding: 10px;
}

.section {
    margin-bottom: 20px;
}

.item-list {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
    gap: 6px;
}

.pick-item {
    cursor: pointer;
    padding: 6px;
    border: 1px solid #ccc;
    border-radius: 4px;
    text-align: center;
    user-select: none;
}

.pick-item.selected {
    background: #4caf50;
    color: white;
    border-color: #4caf50;
}

.rating-row {
    display: flex;
    align-items: center;
    margin-bottom: 10px;
}

.rating-label {
    width: 150px;
    font-weight: bold;
}

.rating-value {
    width: 30px;
    text-align: right;
    margin-left: 8px;
}

input[type=range] {
    width: 250px;
}

button {
    padding: 8px 14px;
    font-size: 14px;
    cursor: pointer;
    margin-top: 10px;
}

pre {
    background: #f5f5f5;
    padding: 10px;
    margin-top: 10px;
}
</style>

<h3>Step 1: Pick up to 5 items</h3>
<div class="section item-list" id="pickList"></div>

<hr>

<h3>Step 2: Rate selected items</h3>
<div class="section" id="ratingPanel">
    <i>No items selected yet.</i>
</div>

<button id="copyBtn">Submit</button>
<pre id="output"></pre>

<script>
(() => {
    const MAX_PICK = 5;

    const items = ['Toy Story (1995)',
 'Braveheart (1995)',
 'Apollo 13 (1995)',
 'Die Hard: With a Vengeance (1995)',
 'Pulp Fiction (1994)',
 'Forrest Gump (1994)',
 'Jurassic Park (1993)',
 "Schindler's List (1993)",
 'Blade Runner (1982)',
 'Aladdin (1992)',
 'Terminator 2: Judgment Day (1991)',
 'Dances with Wolves (1990)',
 'Beauty and the Beast (1991)',
 'Fargo (1996)',
 'Die Hard (1988)',
 'Reservoir Dogs (1992)',
 'E.T. the Extra-Terrestrial (1982)',
 'Monty Python and the Holy Grail (1975)',
 "One Flew Over the Cuckoo's Nest (1975)",
 'Star Wars: Episode V - The Empire Strikes Back (1980)',
 'Aliens (1986)',
 'Star Wars: Episode VI - Return of the Jedi (1983)',
 'Goodfellas (1990)',
 'Alien (1979)',
 'Groundhog Day (1993)',
 'Back to the Future (1985)',
 'Indiana Jones and the Last Crusade (1989)',
 'Good Will Hunting (1997)',
 'Titanic (1997)',
 'Saving Private Ryan (1998)',
 'American History X (1998)',
 'American Beauty (1999)',
 'Fight Club (1999)',
 'Gladiator (2000)',
 'Memento (2000)',
 'Shrek (2001)',
 'Monsters, Inc. (2001)',
 "Ocean's Eleven (2001)",
 'Minority Report (2002)',
 'Finding Nemo (2003)',
 'Pirates of the Caribbean: The Curse of the Black Pearl (2003)',
 'Kill Bill: Vol. 1 (2003)',
 'Eternal Sunshine of the Spotless Mind (2004)',
 'Batman Begins (2005)',
 'WALL·E (2008)',
 'Inception (2010)',
 'Interstellar (2014)'];

    const pickList = document.getElementById("pickList");
    const ratingPanel = document.getElementById("ratingPanel");
    const copyBtn = document.getElementById("copyBtn");

    const selected = new Set();
    const sliders = {};

    items.forEach(item => {
        const div = document.createElement("div");
        div.className = "pick-item";
        div.textContent = item;

        div.onclick = () => {
            if (selected.has(item)) {
                selected.delete(item);
                div.classList.remove("selected");
            } else {
                if (selected.size >= MAX_PICK) {
                    alert("You can pick up to " + MAX_PICK + " items.");
                    return;
                }
                selected.add(item);
                div.classList.add("selected");
            }
            renderRatings();
        };

        pickList.appendChild(div);
    });

    function renderRatings() {
        ratingPanel.innerHTML = "";

        if (selected.size === 0) {
            ratingPanel.innerHTML = "<i>No items selected yet.</i>";
            return;
        }

        selected.forEach(item => {
            const row = document.createElement("div");
            row.className = "rating-row";

            const label = document.createElement("div");
            label.className = "rating-label";
            label.textContent = item;

            const slider = document.createElement("input");
            slider.type = "range";
            slider.min = 0;
            slider.max = 5;
            slider.step = 0.1;
            slider.value = sliders[item] || 0;

            const value = document.createElement("div");
            value.className = "rating-value";
            value.textContent = slider.value;

            slider.oninput = () => {
                value.textContent = slider.value;
                sliders[item] = Number(slider.value);
            };

            row.appendChild(label);
            row.appendChild(slider);
            row.appendChild(value);
            ratingPanel.appendChild(row);
        });
    }

    copyBtn.onclick = () => {
        const result = {};
        selected.forEach(item => {
            result[items.indexOf(item)] = sliders[item] || 0;
        });

        const json = JSON.stringify(result, null, 2);
        document.getElementById("output").textContent = json;

        navigator.clipboard.writeText(json);
    };
})();
</script>
"""

