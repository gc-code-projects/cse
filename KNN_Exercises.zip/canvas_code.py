canvas = """
<style>
.wrapper {
  display: flex;
  gap: 20px;
  align-items: center;
}
canvas {
  border: 2px solid black;
}
button {
  margin-top: 10px;
  font-size: 14px;
}
</style>

<div class="wrapper">
  <div>
    <canvas id="drawCanvas" width="280" height="280"></canvas><br>
    <button onclick="clearCanvas()">Clear</button>
    <button onclick="copyData()">Submit</button>
  </div>
  <div>
    <p><b>28×28 Preview</b></p>
    <canvas id="previewCanvas" width="140" height="140"></canvas>
  </div>
</div>

<textarea id="pixelStore" style="display:none;"></textarea>

<script>
(function () {

const drawCanvas = document.getElementById("drawCanvas");
const ctx = drawCanvas.getContext("2d");
const previewCanvas = document.getElementById("previewCanvas");
const pctx = previewCanvas.getContext("2d");

function initCanvas() {
  ctx.fillStyle = "black";
  ctx.fillRect(0, 0, drawCanvas.width, drawCanvas.height);
  ctx.strokeStyle = "white";
  ctx.lineWidth = 20;
  ctx.lineCap = "round";
  
  pctx.fillStyle = "black";
  pctx.fillRect(0, 0, previewCanvas.width, previewCanvas.height);
  pctx.strokeStyle = "white";
  pctx.lineWidth = 20;
  pctx.lineCap = "round";
}
initCanvas();

let drawing = false;
let lastX = 0, lastY = 0;

drawCanvas.onmousedown = e => {
  drawing = true;
  lastX = e.offsetX;
  lastY = e.offsetY;
};

drawCanvas.onmouseup = () => drawing = false;
drawCanvas.onmouseleave = () => drawing = false;

drawCanvas.onmousemove = e => {
  if (!drawing) return;
  ctx.beginPath();
  ctx.moveTo(lastX, lastY);
  ctx.lineTo(e.offsetX, e.offsetY);
  ctx.stroke();
  lastX = e.offsetX;
  lastY = e.offsetY;
};

window.clearCanvas = () => initCanvas();

function getBoundingBox(img) {
  let minX = 280, minY = 280, maxX = 0, maxY = 0;
  for (let y = 0; y < 280; y++) {
    for (let x = 0; x < 280; x++) {
      let i = (y * 280 + x) * 4;
      if (img.data[i] > 0) {
        minX = Math.min(minX, x);
        minY = Math.min(minY, y);
        maxX = Math.max(maxX, x);
        maxY = Math.max(maxY, y);
      }
    }
  }
  return [minX, minY, maxX, maxY];
}

window.copyData = () => {
  const img = ctx.getImageData(0, 0, 280, 280);
  const [minX, minY, maxX, maxY] = getBoundingBox(img);

  const w = maxX - minX;
  const h = maxY - minY;

  const tempCanvas = document.createElement("canvas");
  tempCanvas.width = 20;
  tempCanvas.height = 20;
  const tctx = tempCanvas.getContext("2d");

  tctx.drawImage(
    drawCanvas,
    minX, minY, w, h,
    0, 0, 20, 20
  );

  const finalCanvas = document.createElement("canvas");
  finalCanvas.width = 28;
  finalCanvas.height = 28;
  const fctx = finalCanvas.getContext("2d");

  fctx.fillStyle = "black";
  fctx.fillRect(0, 0, 28, 28);
  fctx.drawImage(tempCanvas, 4, 4);

  // Show preview
  pctx.imageSmoothingEnabled = false;
  pctx.drawImage(finalCanvas, 0, 0, 140, 140);

  const data = fctx.getImageData(0, 0, 28, 28).data;
  let pixels = [];
  for (let i = 0; i < data.length; i += 4) {
    pixels.push(data[i]);
  }


    // Write the string to the clipboard
    navigator.clipboard.writeText(pixels);
    

};

})();
</script>
"""