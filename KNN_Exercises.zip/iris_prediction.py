iris_classification = """
<div id="knn-root"></div>

<script>
setTimeout(() => {

  /* ================= ROOT ================= */
  const root = document.getElementById("knn-root");
  root.innerHTML = `
    <h3>KNN Interactive Demo (Iris Dataset)</h3>

    <label>Choose k:</label>
    <select id="kSelect"></select>

    <button id="predictBtn">Predict (Manual)</button>
    <button id="trueBtn">Show True Neighbors</button>
    <button id="clearBtn">Clear</button>

    <p>Prediction: <b><span id="prediction">None</span></b></p>

    <canvas id="plot" width="600" height="400"
            style="border:1px solid black;"></canvas>
  `;

  /* ================= DATA ================= */

  const data = [[1.4, 0.2, 'Setosa'],
       [1.3, 0.2, 'Setosa'],
       [1.5, 0.2, 'Setosa'],
       [1.7, 0.4, 'Setosa'],
       [1.4, 0.3, 'Setosa'],
       [1.5, 0.1, 'Setosa'],
       [1.6, 0.2, 'Setosa'],
       [1.4, 0.1, 'Setosa'],
       [1.1, 0.1, 'Setosa'],
       [1.2, 0.2, 'Setosa'],
       [1.5, 0.4, 'Setosa'],
       [1.3, 0.4, 'Setosa'],
       [1.7, 0.3, 'Setosa'],
       [1.5, 0.3, 'Setosa'],
       [1.7, 0.2, 'Setosa'],
       [1.0, 0.2, 'Setosa'],
       [1.7, 0.5, 'Setosa'],
       [1.9, 0.2, 'Setosa'],
       [1.6, 0.4, 'Setosa'],
       [1.3, 0.3, 'Setosa'],
       [1.6, 0.6, 'Setosa'],
       [1.9, 0.4, 'Setosa'],
       [4.7, 1.4, 'Versicolor'],
       [4.5, 1.5, 'Versicolor'],
       [4.9, 1.5, 'Versicolor'],
       [4.0, 1.3, 'Versicolor'],
       [4.6, 1.5, 'Versicolor'],
       [4.5, 1.3, 'Versicolor'],
       [4.7, 1.6, 'Versicolor'],
       [3.3, 1.0, 'Versicolor'],
       [4.6, 1.3, 'Versicolor'],
       [3.9, 1.4, 'Versicolor'],
       [3.5, 1.0, 'Versicolor'],
       [4.2, 1.5, 'Versicolor'],
       [4.0, 1.0, 'Versicolor'],
       [3.6, 1.3, 'Versicolor'],
       [4.4, 1.4, 'Versicolor'],
       [4.1, 1.0, 'Versicolor'],
       [3.9, 1.1, 'Versicolor'],
       [4.8, 1.8, 'Versicolor'],
       [4.7, 1.2, 'Versicolor'],
       [4.3, 1.3, 'Versicolor'],
       [4.8, 1.4, 'Versicolor'],
       [5.0, 1.7, 'Versicolor'],
       [3.8, 1.1, 'Versicolor'],
       [3.7, 1.0, 'Versicolor'],
       [3.9, 1.2, 'Versicolor'],
       [5.1, 1.6, 'Versicolor'],
       [4.5, 1.6, 'Versicolor'],
       [4.7, 1.5, 'Versicolor'],
       [4.4, 1.3, 'Versicolor'],
       [4.1, 1.3, 'Versicolor'],
       [4.4, 1.2, 'Versicolor'],
       [4.6, 1.4, 'Versicolor'],
       [4.0, 1.2, 'Versicolor'],
       [4.2, 1.3, 'Versicolor'],
       [4.2, 1.2, 'Versicolor'],
       [3.0, 1.1, 'Versicolor'],
       [6.0, 2.5, 'Virginica'],
       [5.1, 1.9, 'Virginica'],
       [5.9, 2.1, 'Virginica'],
       [5.6, 1.8, 'Virginica'],
       [5.8, 2.2, 'Virginica'],
       [6.6, 2.1, 'Virginica'],
       [4.5, 1.7, 'Virginica'],
       [6.3, 1.8, 'Virginica'],
       [5.8, 1.8, 'Virginica'],
       [6.1, 2.5, 'Virginica'],
       [5.1, 2.0, 'Virginica'],
       [5.3, 1.9, 'Virginica'],
       [5.5, 2.1, 'Virginica'],
       [5.0, 2.0, 'Virginica'],
       [5.1, 2.4, 'Virginica'],
       [5.3, 2.3, 'Virginica'],
       [5.5, 1.8, 'Virginica'],
       [6.7, 2.2, 'Virginica'],
       [6.9, 2.3, 'Virginica'],
       [5.0, 1.5, 'Virginica'],
       [5.7, 2.3, 'Virginica'],
       [4.9, 2.0, 'Virginica'],
       [6.7, 2.0, 'Virginica'],
       [4.9, 1.8, 'Virginica'],
       [5.7, 2.1, 'Virginica'],
       [6.0, 1.8, 'Virginica'],
       [4.8, 1.8, 'Virginica'],
       [5.6, 2.1, 'Virginica'],
       [5.8, 1.6, 'Virginica'],
       [6.1, 1.9, 'Virginica'],
       [6.4, 2.0, 'Virginica'],
       [5.6, 2.2, 'Virginica'],
       [5.1, 1.5, 'Virginica'],
       [5.6, 1.4, 'Virginica'],
       [6.1, 2.3, 'Virginica'],
       [5.6, 2.4, 'Virginica'],
       [5.4, 2.1, 'Virginica'],
       [5.1, 2.3, 'Virginica'],
       [5.9, 2.3, 'Virginica'],
       [5.7, 2.5, 'Virginica'],
       [5.2, 2.3, 'Virginica'],
       [5.0, 1.9, 'Virginica'],
       [5.2, 2.0, 'Virginica'],
       [5.4, 2.3, 'Virginica'],
       [5.1, 1.8, 'Virginica']];

  const colors = {
    Setosa: "red",
    Versicolor: "green",
    Virginica: "blue"
  };

  /* ================= DOM ================= */
  const canvas = document.getElementById("plot");
  const ctx = canvas.getContext("2d");
  const kSelect = document.getElementById("kSelect");
  const predSpan = document.getElementById("prediction");

  /* ================= STATE ================= */
  let query = null;
  let chosen = [];
  let truth = [];
  let promptText = "Click on the canvas to place a new flower.";

  /* ================= DROPDOWN ================= */
  for (let i=1;i<=10;i++) {
    const o = document.createElement("option");
    o.value = i;
    o.textContent = i;
    kSelect.appendChild(o);
  }

  /* ================= SCALE ================= */
  const xs = data.map(d=>d[0]);
  const ys = data.map(d=>d[1]);
  const sx = x => 50 + (x - Math.min(...xs)) /
    (Math.max(...xs)-Math.min(...xs)) * 500;
  const sy = y => 350 - (y - Math.min(...ys)) /
    (Math.max(...ys)-Math.min(...ys)) * 300;

  /* ================= DRAW ================= */
  function drawPrompt() {
    ctx.fillStyle = "rgba(255,255,255,0.9)";
    ctx.fillRect(5, 5, 460, 40);
    ctx.fillStyle = "black";
    ctx.font = "14px Arial";
    ctx.fillText(promptText, 15, 30);
  }

  function drawLegend() {
    const x = 500, y = 300;
    ctx.fillStyle = "rgba(255,255,255,0.9)";
    ctx.fillRect(x-10, y-25, 140, 90);

    ctx.font = "14px Arial";
    let i = 0;
    for (const [label, color] of Object.entries(colors)) {
      ctx.beginPath();
      ctx.arc(x, y + i*25, 6, 0, Math.PI*2);
      ctx.fillStyle = color;
      ctx.fill();

      ctx.fillStyle = "black";
      ctx.fillText(label, x + 15, y + 5 + i*25);
      i++;
    }
  }

  function draw() {
    ctx.clearRect(0,0,600,400);

    data.forEach(d => {
      ctx.beginPath();
      ctx.arc(sx(d[0]), sy(d[1]), 5, 0, Math.PI*2);
      ctx.fillStyle = colors[d[2]];
      ctx.fill();
    });

    if (query) {
      ctx.beginPath();
      ctx.arc(query.x, query.y, 6, 0, Math.PI*2);
      ctx.fillStyle = "black";
      ctx.fill();
    }

    chosen.forEach(i => {
      ctx.beginPath();
      ctx.arc(sx(data[i][0]), sy(data[i][1]), 10, 0, Math.PI*2);
      ctx.strokeStyle = "orange";
      ctx.stroke();
    });

    truth.forEach(i => {
      ctx.beginPath();
      ctx.moveTo(query.x, query.y);
      ctx.lineTo(sx(data[i][0]), sy(data[i][1]));
      ctx.strokeStyle = "gray";
      ctx.stroke();
    });

    drawPrompt();
    drawLegend();
  }

  /* ================= EVENTS ================= */
  canvas.onclick = e => {
    const r = canvas.getBoundingClientRect();
    const x = e.clientX - r.left;
    const y = e.clientY - r.top;

    if (!query) {
      query = {x, y};
      chosen = [];
      truth = [];
      promptText = `Choose ${kSelect.value} neighbors by clicking nearby points.`;
      draw();
      return;
    }

    if (chosen.length >= kSelect.value) return;

    let best = 1e9, idx = null;
    data.forEach((d,i) => {
      const dist = Math.hypot(sx(d[0])-x, sy(d[1])-y);
      if (dist < best) { best = dist; idx = i; }
    });

    if (best < 12 && !chosen.includes(idx)) {
      chosen.push(idx);
      promptText = `Selected ${chosen.length}/${kSelect.value} neighbors.`;
      draw();
    }
  };

  kSelect.onchange = () => {
    if (query) {
      chosen = [];
      truth = [];
      promptText = `Choose ${kSelect.value} neighbors by clicking nearby points.`;
      draw();
    }
  };

  document.getElementById("predictBtn").onclick = () => {
    const c = {};
    chosen.forEach(i => c[data[i][2]] = (c[data[i][2]]||0)+1);
    predSpan.textContent =
      Object.entries(c).sort((a,b)=>b[1]-a[1])[0]?.[0] || "None";
  };

  document.getElementById("trueBtn").onclick = () => {
    const k = +kSelect.value;
    truth = data.map((d,i)=>[i,(sx(d[0])-query.x)**2+(sy(d[1])-query.y)**2])
      .sort((a,b)=>a[1]-b[1]).slice(0,k).map(d=>d[0]);

    const c = {};
    truth.forEach(i => c[data[i][2]] = (c[data[i][2]]||0)+1);
    predSpan.textContent =
      Object.entries(c).sort((a,b)=>b[1]-a[1])[0][0];

    promptText = "True nearest neighbors shown (gray lines).";
    draw();
  };

  document.getElementById("clearBtn").onclick = () => {
    query = null;
    chosen = [];
    truth = [];
    predSpan.textContent = "None";
    promptText = "Click on the canvas to place a new flower.";
    draw();
  };

  draw();

}, 100);
</script>
"""
