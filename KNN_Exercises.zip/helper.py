import matplotlib.pyplot as plt
import numpy as np

def draw(df, idx):
    # Pick one digit
    digit = df.values[idx]
    x, y = digit[1:], digit[0]
    image = x.reshape(28, 28)

    # Normalize to 0–255 integers (MNIST is already 0–255, but be explicit)
    image_int = image.astype(int)

    # Create figure
    fig, axs = plt.subplots(1, 2, figsize=(12, 8))

    # ---- Left: Grayscale image ----
    axs[0].imshow(image_int, cmap="gray")
    axs[0].set_title(f"MNIST Digit (Label = {y})")
    axs[0].axis("off")

    # ---- Right: 28×28 numeric grid ----
    axs[1].imshow(np.zeros_like(image_int), cmap="gray_r")
    axs[1].set_title("28×28 Pixel Values (0–255)")
    axs[1].axis("off")

    # Overlay pixel values
    for i in range(28):
        for j in range(28):
            value = image_int[i, j]
            axs[1].text(
                j, i, str(value),
                ha="center", va="center",
                fontsize=6,
                # color="red" if value > 128 else "black"
            )

movie_chinese_name = {
    'Toy Story (1995)': '《玩具总动员》',
    'Braveheart (1995)': '《勇敢的心》',
    'Apollo 13 (1995)': '《阿波罗13号》',
    'Die Hard: With a Vengeance (1995)': '《虎胆龙威3》',
    'Pulp Fiction (1994)': '《低俗小说》',
    'Forrest Gump (1994)': '《阿甘正传》',
    'Jurassic Park (1993)': '《侏罗纪公园》',
    "Schindler's List (1993)": '《辛德勒的名单》',
    'Blade Runner (1982)': '《银翼杀手》',
    'Aladdin (1992)': '《阿拉丁》',
    'Terminator 2: Judgment Day (1991)': '《终结者2：审判日》',
    'Dances with Wolves (1990)': '《与狼共舞》',
    'Beauty and the Beast (1991)': '《美女与野兽》',
    'Fargo (1996)': '《冰血暴》',
    'Die Hard (1988)': '《虎胆龙威》',
    'Reservoir Dogs (1992)': '《落水狗》',
    'E.T. the Extra-Terrestrial (1982)': '《E.T.外星人》',
    'Monty Python and the Holy Grail (1975)': '《巨蟒与圣杯》',
    "One Flew Over the Cuckoo's Nest (1975)": '《飞越疯人院》',
    'Star Wars: Episode V - The Empire Strikes Back (1980)': '《星球大战5：帝国反击战》',
    'Aliens (1986)': '《异形2》',
    'Star Wars: Episode VI - Return of the Jedi (1983)': '《星球大战6：绝地归来》',
    'Goodfellas (1990)': '《好家伙》',
    'Alien (1979)': '《异形》',
    'Groundhog Day (1993)': '《土拨鼠之日》',
    'Back to the Future (1985)': '《回到未来》',
    'Indiana Jones and the Last Crusade (1989)': '《夺宝奇兵3：圣战奇兵》',
    'Good Will Hunting (1997)': '《心灵捕手》',
    'Titanic (1997)': '《泰坦尼克号》',
    'Saving Private Ryan (1998)': '《拯救大兵瑞恩》',
    'American History X (1998)': '《美国X档案》',
    'American Beauty (1999)': '《美国丽人》',
    'Fight Club (1999)': '《搏击俱乐部》',
    'Gladiator (2000)': '《角斗士》',
    'Memento (2000)': '《记忆碎片》',
    'Shrek (2001)': '《怪物史莱克》',
    'Monsters, Inc. (2001)': '《怪兽电力公司》',
    "Ocean's Eleven (2001)": '《十一罗汉》',
    'Minority Report (2002)': '《少数派报告》',
    'Finding Nemo (2003)': '《海底总动员》',
    'Pirates of the Caribbean: The Curse of the Black Pearl (2003)': '《加勒比海盗：黑珍珠号的诅咒》',
    'Kill Bill: Vol. 1 (2003)': '《杀死比尔1》',
    'Eternal Sunshine of the Spotless Mind (2004)': '《美丽心灵的永恒阳光》',
    'Batman Begins (2005)': '《蝙蝠侠：侠影之谜》',
    'WALL·E (2008)': '《机器人总动员》',
    'Inception (2010)': '《盗梦空间》',
    'Interstellar (2014)': '《星际穿越》'
}